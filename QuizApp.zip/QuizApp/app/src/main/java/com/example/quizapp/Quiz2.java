package com.example.quizapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class Quiz2 extends AppCompatActivity {
    RadioGroup rg;
    RadioButton rb;
    int score;
    String repCorrect = "True";
    Button bFinish;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz2);

        rg = (RadioGroup) findViewById(R.id.rg);
        bFinish = (Button) findViewById(R.id.bFinish);
        Intent intent = getIntent();
        score = intent.getIntExtra("score", 0);

        bFinish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(rg.getCheckedRadioButtonId() == -1){
                    Toast.makeText(getApplicationContext(), "merci de choisir une reponse svp !", Toast.LENGTH_SHORT).show();
                }
                else{
                    rb = (RadioButton) findViewById(rg.getCheckedRadioButtonId());
                    if(rb.getText().toString().equals(repCorrect)){
                        score += 1;
                    }
                    Intent intent = new Intent(Quiz2.this, Score.class);
                    intent.putExtra("score", score);
                    startActivity(intent);
                    //overridePendingTransition(R.anim.exit, R.anim.entry);
                    finish();
                }

            }
        });
    }
}
