package com.example.quizapp;

public class Connect {
    public static final String URL_LOGIN = "http://192.168.0.197/quizApp/login.php";
    public static final String URL_REGISTER = "http://192.168.0.197/quizApp/insert.php";
}
