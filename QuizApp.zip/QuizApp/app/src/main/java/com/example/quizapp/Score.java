package com.example.quizapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
//new
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.formatter.PercentFormatter;
import com.github.mikephil.charting.utils.ColorTemplate;

import java.util.ArrayList;

public class Score extends AppCompatActivity {
    int score;
    int total = 2;
    Button bExit, bRestart;
    TextView tvScore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_score);
        //Pie
        PieChart pieChart = findViewById(R.id.piechart);
        ArrayList answers = new ArrayList();
        //
        bExit = (Button) findViewById(R.id.bExit);
        bRestart = (Button) findViewById(R.id.bRestart);
        tvScore = (TextView) findViewById(R.id.tvScore);

        Intent intent = getIntent();
        score = intent.getIntExtra("score", 0);

        tvScore.setText("Your score is : " + score);

        answers.add(new Entry(total-score, 0));
        answers.add(new Entry(score, 1));
        PieDataSet dataSet = new PieDataSet(answers, "Answers");

        ArrayList titre = new ArrayList();

        titre.add("Wrong Answer");
        titre.add("Correct Answer");
        PieData data = new PieData(titre, dataSet);
        pieChart.setData(data);
        dataSet.setColors(ColorTemplate.COLORFUL_COLORS);
        pieChart.animateXY(5000, 5000);

        bRestart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Score.this, Quiz1.class));
            }
        });

        bExit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
                System.exit(0);
            }
        });
    }
}
